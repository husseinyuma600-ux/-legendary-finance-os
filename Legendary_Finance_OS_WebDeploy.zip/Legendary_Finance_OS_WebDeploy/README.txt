LEGENDARY FINANCE OS — DEPLOYMENT PACKAGE

This package contains index.html, the app entry point.

Why this package exists:
Opening an HTML file from an iPhone Files/ChatGPT preview can fail to retain browser storage between sessions. Hosting the app at a stable HTTPS website is the recommended next step.

Important:
- This package does not itself host the app or create a public URL.
- Until hosted and tested, do not rely on the app as the only copy of your financial records.
- Use the app's Export backup feature regularly and keep the JSON backup somewhere safe.
- The app is a manual tracker and does not connect to banks or mobile-money providers.
